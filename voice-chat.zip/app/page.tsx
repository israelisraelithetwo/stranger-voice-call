"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, PhoneOff } from "lucide-react"
import { io, type Socket } from "socket.io-client"

export default function VoiceChat() {
  const [room, setRoom] = useState("")
  const [isConnected, setIsConnected] = useState(false)
  const [isJoined, setIsJoined] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [status, setStatus] = useState("מנותק")
  const [error, setError] = useState("")

  const socketRef = useRef<Socket | null>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)
  const remoteAudioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    // Initialize socket connection
    socketRef.current = io()

    socketRef.current.on("connect", () => {
      setIsConnected(true)
      setStatus("מחובר לשרת")
    })

    socketRef.current.on("disconnect", () => {
      setIsConnected(false)
      setStatus("מנותק")
      handleHangup()
    })

    socketRef.current.on("ready", () => {
      setStatus("משתמש שני הצטרף - מתחיל שיחה")
      createPeer(true)
    })

    socketRef.current.on("signal", (data) => {
      handleSignal(data)
    })

    socketRef.current.on("user-disconnected", () => {
      setStatus("המשתמש השני התנתק")
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = null
      }
    })

    // Cleanup on component unmount
    return () => {
      handleHangup()
      socketRef.current?.disconnect()
    }
  }, [])

  const joinRoom = async () => {
    if (!room) {
      setError("נא להזין שם חדר")
      return
    }

    try {
      setError("")
      setStatus("מבקש גישה למיקרופון...")

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: true,
        video: false,
      })

      localStreamRef.current = stream
      setIsJoined(true)
      setStatus("הצטרפת לחדר, ממתין למשתמש נוסף...")

      // Create audio element for remote stream
      if (!remoteAudioRef.current) {
        const audio = new Audio()
        audio.autoplay = true
        remoteAudioRef.current = audio
      }

      socketRef.current?.emit("join", room)
    } catch (err) {
      console.error("Error accessing microphone:", err)
      setError("שגיאה בגישה למיקרופון. אנא ודא שיש לך מיקרופון פעיל ושהענקת הרשאות.")
    }
  }

  const createPeer = (isCaller: boolean) => {
    const servers = {
      iceServers: [{ urls: "stun:stun.l.google.com:19302" }],
    }

    peerConnectionRef.current = new RTCPeerConnection(servers)

    // Add local tracks to the peer connection
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => {
        if (localStreamRef.current) {
          peerConnectionRef.current?.addTrack(track, localStreamRef.current)
        }
      })
    }

    // Handle incoming tracks (remote audio)
    peerConnectionRef.current.ontrack = (event) => {
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = event.streams[0]
        setStatus("בשיחה")
      }
    }

    // Handle ICE candidates
    peerConnectionRef.current.onicecandidate = (event) => {
      if (event.candidate) {
        socketRef.current?.emit("signal", {
          room: room,
          signal: { candidate: event.candidate },
        })
      }
    }

    // If this peer is the caller, create an offer
    if (isCaller && peerConnectionRef.current) {
      peerConnectionRef.current
        .createOffer()
        .then((offer) => {
          if (peerConnectionRef.current) {
            return peerConnectionRef.current.setLocalDescription(offer)
          }
          return Promise.reject("No peer connection")
        })
        .then(() => {
          socketRef.current?.emit("signal", {
            room: room,
            signal: { sdp: peerConnectionRef.current?.localDescription },
          })
        })
        .catch((err) => {
          console.error("Error creating offer:", err)
          setError("שגיאה ביצירת החיבור")
        })
    }
  }

  const handleSignal = (data: any) => {
    const signal = data

    if (!peerConnectionRef.current) {
      createPeer(false)
    }

    if (signal.sdp) {
      peerConnectionRef.current
        ?.setRemoteDescription(new RTCSessionDescription(signal.sdp))
        .then(() => {
          // If we received an offer, create an answer
          if (signal.sdp.type === "offer" && peerConnectionRef.current) {
            return peerConnectionRef.current.createAnswer()
          }
          return undefined
        })
        .then((answer) => {
          if (answer && peerConnectionRef.current) {
            return peerConnectionRef.current.setLocalDescription(answer)
          }
          return undefined
        })
        .then(() => {
          if (signal.sdp.type === "offer") {
            socketRef.current?.emit("signal", {
              room: room,
              signal: { sdp: peerConnectionRef.current?.localDescription },
            })
          }
        })
        .catch((err) => {
          console.error("Error handling SDP signal:", err)
          setError("שגיאה בחיבור")
        })
    } else if (signal.candidate) {
      peerConnectionRef.current?.addIceCandidate(new RTCIceCandidate(signal.candidate)).catch((err) => {
        console.error("Error adding ICE candidate:", err)
      })
    }
  }

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTracks = localStreamRef.current.getAudioTracks()
      audioTracks.forEach((track) => {
        track.enabled = !track.enabled
      })
      setIsMuted(!isMuted)
    }
  }

  const handleHangup = () => {
    // Close peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
      peerConnectionRef.current = null
    }

    // Stop all tracks in local stream
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach((track) => track.stop())
      localStreamRef.current = null
    }

    // Clear remote audio
    if (remoteAudioRef.current) {
      remoteAudioRef.current.srcObject = null
    }

    setIsJoined(false)
    setIsMuted(false)
    setStatus("מנותק")
  }

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-50 p-4" dir="rtl">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-2xl">שיחה קולית</CardTitle>
          <CardDescription>
            {isConnected ? (
              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                מחובר לשרת
              </Badge>
            ) : (
              <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                מנותק מהשרת
              </Badge>
            )}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!isJoined ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <label htmlFor="room" className="text-sm font-medium">
                  שם החדר
                </label>
                <Input id="room" placeholder="הזן שם חדר" value={room} onChange={(e) => setRoom(e.target.value)} />
              </div>
              {error && <p className="text-sm text-red-500">{error}</p>}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="p-4 bg-gray-100 rounded-lg text-center">
                <p className="font-medium">חדר: {room}</p>
                <p className="text-sm text-gray-500 mt-1">{status}</p>
              </div>
              <div className="flex justify-center gap-4">
                <Button
                  variant={isMuted ? "default" : "outline"}
                  size="icon"
                  onClick={toggleMute}
                  className={isMuted ? "bg-amber-600 hover:bg-amber-700" : ""}
                >
                  {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
                </Button>
                <Button variant="destructive" size="icon" onClick={handleHangup}>
                  <PhoneOff className="h-5 w-5" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
        <CardFooter>
          {!isJoined && (
            <Button className="w-full" onClick={joinRoom} disabled={!isConnected || !room}>
              הצטרף לחדר
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}
