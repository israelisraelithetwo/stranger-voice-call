import type { Server as NetServer } from "http"
import { Server as SocketIOServer } from "socket.io"
import type { NextRequest } from "next/server"

export const dynamic = "force-dynamic"

// Global variable to store the Socket.IO server instance
let io: SocketIOServer

export async function GET(req: NextRequest) {
  // Get the raw Node.js HTTP server instance
  const res = new Response("Socket API route")
  const httpServer = res.socket?.server as unknown as NetServer

  // Initialize Socket.IO if it hasn't been already
  if (!httpServer.io) {
    console.log("Initializing Socket.IO server...")
    io = new SocketIOServer(httpServer, {
      path: "/api/socket/io",
      addTrailingSlash: false,
    })

    // Store the Socket.IO server instance on the HTTP server
    httpServer.io = io

    // Socket.IO event handlers
    io.on("connection", (socket) => {
      console.log("Client connected:", socket.id)

      socket.on("join", (room) => {
        socket.join(room)
        const clients = io.sockets.adapter.rooms.get(room)
        console.log(`Client ${socket.id} joined room ${room}. Clients in room: ${clients?.size}`)

        if (clients && clients.size === 2) {
          console.log(`Room ${room} is ready with 2 clients. Emitting 'ready' event.`)
          io.to(room).emit("ready")
        }
      })

      socket.on("signal", (data) => {
        console.log(`Signaling from ${socket.id} to room ${data.room}`)
        socket.to(data.room).emit("signal", data.signal)
      })

      socket.on("disconnect", () => {
        console.log("Client disconnected:", socket.id)
        // Notify all rooms this socket was in
        socket.rooms.forEach((room) => {
          if (room !== socket.id) {
            socket.to(room).emit("user-disconnected")
          }
        })
      })
    })
  }

  return res
}
